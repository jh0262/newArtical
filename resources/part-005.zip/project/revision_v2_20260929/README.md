# 重载机器人短历史补偿论文：修订版交付入口

本版对应2026年9月29日关于聚焦、文献、说明文档、理论及实验深度的修改意见。原稿和原始研究文件均保留。

随后根据作者关于统一论文叙述的意见，清除了正文中的“补充实验”等过程性表述，按实验内容组织方法和结果；详见`论文叙述修订记录.md`。最新编辑核验为`editorial_verification.json`，原计算代码快照与历史核验继续保留。

## 正文与说明

- [Word修订稿](F:/暑假原始资料/06_projects/Retzler_History_Step4_20260928/revision_v2_20260929/重载机器人短历史补偿_论文修订稿.docx)：12页，9个可编辑公式、5幅结果图、4张表、18篇参考文献。
- [PDF阅读版](F:/暑假原始资料/06_projects/Retzler_History_Step4_20260928/revision_v2_20260929/render_qa/manuscript.pdf)：由本机Word原生渲染。
- [修订说明与问题清单](F:/暑假原始资料/06_projects/Retzler_History_Step4_20260928/revision_v2_20260929/修订说明与问题清单.md)：四项意见的处理与投稿前证据缺口。
- [研究与复现说明](F:/暑假原始资料/06_projects/Retzler_History_Step4_20260928/revision_v2_20260929/研究与复现说明.md)：数据、单位、字段、流程、命令及环境依赖。
- [理论推导与证据边界](F:/暑假原始资料/06_projects/Retzler_History_Step4_20260928/revision_v2_20260929/理论推导与证据边界.md)：公式推导、成立条件和解释限制。
- [文献证据矩阵](F:/暑假原始资料/06_projects/Retzler_History_Step4_20260928/revision_v2_20260929/文献证据矩阵.md)：每篇文献的来源、证据位置、用途与边界。
- [论点证据矩阵](F:/暑假原始资料/06_projects/Retzler_History_Step4_20260928/revision_v2_20260929/论点证据矩阵.md)：正文论点与数据、代码、理论逐项对应。

## 本轮结果的核心含义

重复当前速度的网络与单输入网络具有相同函数类，因此必须把它作为重参数化对照。实际完成27次补充候选训练后，在4 ms积分协议下，真实历史模型相对该对照的完整轨迹和低速位置误差均值降低；冻结权重历史移除及点态加速度比较也支持网络确实使用了延迟差分。但固定50个起点的积分细化使相对降幅从13.14%缩小到6.74%。全文明确报告这种数值敏感性，未把结果写成步长无关优势。

这是一份证据边界明确的研究修订稿。全量积分收敛、独立轨迹和成熟动态摩擦/循环模型对照尚未完成，目前不能仅凭格式和引用数量认定为可直接投稿版本。

## 如何复算

在本机PowerShell运行`reproduce_revision.ps1`，从保存预测重建CSV及图；本轮已实际执行这一入口。`-Retrain`会另建目录并重做全部27次候选训练及后续预测，不会覆盖原结果；该包装分支仅静态检查，研究阶段本身均已实际运行。

计算依赖父项目输入、物理缓存、源代码及工作区`.venv-v3`和`.v3deps`，绘图另依赖父项目`plot_deps`。不应将本目录单独复制后宣称无需依赖即可执行。`source_snapshot/`保存本轮与所依赖父项目脚本快照，`source_snapshot_manifest.json`记录来源和哈希；快照用于审计，运行仍以原项目结构为准。具体版本见`verification.json`。

原稿目录：`../manuscript_step5/`。本版Markdown正文由`assemble_manuscript.py`将`manuscript_template.md`与结果拼接；Word由`build_docx.py`生成。若修改正文模板或生成数值段，应重新生成Word并渲染核对，避免正文与PDF不同步。

## 质量检查记录

- `verification.json`：数据、候选、指标、脚本语法、文档结构与未完成验证项目。
- `render_qa/visual_review.json`：最终Word原生渲染12页的逐页检查及文件哈希。
- `render_packaged.log`：通用渲染器因本机缺少LibreOffice失败的记录；最终版已使用Word成功渲染，没有据失败记录声称完成预览。
